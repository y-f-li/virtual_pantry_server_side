package ch.uzh.ifi.hase.soprafs26.entity;

import jakarta.persistence.*;

import ch.uzh.ifi.hase.soprafs26.constant.UserStatus;

import java.io.Serializable;

import java.time.Instant;

/**
 * Internal User Representation
 * This class composes the internal representation of the user and defines how
 * the user is stored in the database.
 * Every variable will be mapped into a database field with the @Column
 * annotation
 * - nullable = false -> this cannot be left empty
 * - unique = true -> this value must be unqiue across the database -> composes
 * the primary key
 */
@Entity // this class is stored in a table
@Table(name = "users") // The table name is users
public class User implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id // Primary key
	@GeneratedValue
	private Long id;

	@Column(nullable = false)
	private String password;

	@Column(nullable = false, unique = true) // Needs not to be empty and the entry must be unique
	private String username;

	@Column(nullable = false, unique = true)
	private String token;

	@Column(nullable = false)
	private UserStatus status;

	@Column(nullable = true)
	private String bio;

	@Column(nullable = false, updatable = false)
	private Instant creationDate;

	@PrePersist
	protected void onCreate() {
	if (this.creationDate == null) {
		this.creationDate = Instant.now();
	}
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getBio() { return bio; }
	public void setBio(String bio) { this.bio = bio; }

	public Instant getCreationDate() { return creationDate; }
	public void setCreationDate(Instant creationDate) { this.creationDate = creationDate; }

	public UserStatus getStatus() {
		return status;
	}

	public void setStatus(UserStatus status) {
		this.status = status;
	}
}
